params <-
  list(version = 1.1, `version-date` = "2019/05/31")

## ----setup, include=FALSE------------------------------------------------
knitr::opts_chunk$set(echo = FALSE, message = FALSE)
knitr::opts_knit$set(root.dir = normalizePath("../../"))
library(tidyverse)
theme_set(theme_minimal(base_family = "Arial Unicode MS"))

#### TR: needed to add
library(devtools)
install_github("stefanocoretta/coretta2019eng")
#####

library(coretta2019eng) # https://github.com/stefanocoretta/coretta2019eng
data("eng_durations")
library(brms)
library(tidybayes)
library(broom.mixed)
library(knitr)
library(kableExtra)
library(tidyverse)
eng_durations_rr <- na.omit(eng_durations)
eng_clos <- na.omit(eng_durations)


## ----rr-1----------------------------------------------------------------
priors_SC <- c(
  set_prior("normal(200, 50)", class = "Intercept"),
  set_prior("normal(0, 25)", class = "b", coef = "voicingvoiced"),
  set_prior("normal(50, 25)", class = "b", coef = "num_sylmono"),
  set_prior("normal(50, 25)", class = "b", coef = "voicingvoiced:num_sylmono"),
  set_prior("normal(-25, 10)", class = "b", coef = "speech_rate_c"),
  set_prior("cauchy(0, 25)", class = "sd"),
  set_prior("lkj(2)", class = "cor"),
  set_prior("cauchy(0, 25)", class = "sigma")
)

# TR: my more conservative priors
priors_TR <- c(
  set_prior("normal(200, 50)", class = "Intercept"),
  ## TR: I'd use a wider prior, especially if you compare them to magnitudes in literature
  set_prior("normal(0, 75)", class = "b", coef = "voicingvoiced"),
  set_prior("normal(50, 75)", class = "b", coef = "num_sylmono"),
  ## TR: Here you build in an informative prior for a relevant test (also in the text you say they are the same as voicing above)
  ## I'd suggest using a weakly informative prior around zero
  set_prior("normal(0, 75)", class = "b", coef = "voicingvoiced:num_sylmono"),
  set_prior("normal(-25, 10)", class = "b", coef = "speech_rate_c"),
  set_prior("cauchy(0, 75)", class = "sd"),
  set_prior("lkj(2)", class = "cor"),
  set_prior("cauchy(0, 75)", class = "sigma")
)


# The model with the author's priors
rr_1_SC <- brm(
  rel_rel ~
    voicing +
    num_syl +
    voicing:num_syl +
    speech_rate_c +
    (1 + voicing | speaker) +
    (1 | word),
  family = gaussian(),
  data = eng_durations_rr,
  prior = priors_SC,
  cores = 4,
  seed = 1234,
)

# TR: The model with my more conservative priors
rr_1_TR <- brm(
  rel_rel ~
    voicing +
    num_syl +
    voicing:num_syl +
    speech_rate_c +
    (1 + voicing | speaker) +
    (1 | word),
  family = gaussian(),
  data = eng_durations_rr,
  prior = priors_TR,
  cores = 4,
  seed = 1234,
)

# TR: my model with more conservative random slopes
rr_1_TR_slopes <- brm(
  rel_rel ~
    voicing +
    num_syl +
    voicing:num_syl +
    speech_rate_c +
    (1 + voicing * num_syl | speaker) +
    (1 | word),
  family = gaussian(),
  data = eng_durations_rr,
  prior = priors_TR,
  cores = 4,
  seed = 1234,
)


## save models for later use

# Getting the path of your current open file
library(rstudioapi)
datapath = rstudioapi::getActiveDocumentContext()$path 
setwd(dirname(datapath))
setwd("models/")

save(rr_1_SC, 
     rr_1_TR,
     rr_1_TR_slopes,
     file = "Models1.RData")


##############################
### TR: Extract posteriors ###
##############################

setwd("models/")
load("Models1.RData")

## extract posteriors for all three models:
# spits out a model with samples for newly defined parameters
psamples_SC = posterior_samples(rr_1_SC) %>% 
  mutate(
    # intercept = dummy voiceless for disyllabic
    voiceless_disyllabic = b_Intercept,
    # add coefficient for num_sylmono = dummy voiceless for monosyllabic
    voiceless_monosyllabic = b_Intercept + b_num_sylmono,
    # add coefficient for voicingvoiced for dummy voiced disyllabic
    voiced_disyllabic = voiceless_disyllabic + b_voicingvoiced,
    # add coefficient for voicingvoiced and interaction term for dummy voiced monosyllabic
    voiced_monosyllabic = voiceless_monosyllabic + b_voicingvoiced + `b_voicingvoiced:num_sylmono`,
    # difference between monosyllabic according to voicing 
    delta_voicing_mono = voiceless_monosyllabic - voiced_monosyllabic,
    # difference between disyllabic according to voicing
    delta_voicing_di = voiceless_disyllabic - voiced_disyllabic,
    # difference between difference = the traditional standardized interaction term
    # i.e. how much does the voicing effect differ according to syll number
    delta_voicing_mono_di = delta_voicing_mono - delta_voicing_di
  )

psamples_TR = posterior_samples(rr_1_TR) %>% 
  mutate(
    voiceless_disyllabic = b_Intercept,
    voiceless_monosyllabic = b_Intercept + b_num_sylmono,
    voiced_disyllabic = voiceless_disyllabic + b_voicingvoiced,
    voiced_monosyllabic = voiceless_monosyllabic + b_voicingvoiced + `b_voicingvoiced:num_sylmono`,
    delta_voicing_mono = voiceless_monosyllabic - voiced_monosyllabic,
    delta_voicing_di = voiceless_disyllabic - voiced_disyllabic,
    delta_voicing_mono_di = delta_voicing_mono - delta_voicing_di
  )

psamples_TR_slopes = posterior_samples(rr_1_TR_slopes) %>% 
  mutate(
    voiceless_disyllabic = b_Intercept,
    voiceless_monosyllabic = b_Intercept + b_num_sylmono,
    voiced_disyllabic = voiceless_disyllabic + b_voicingvoiced,
    voiced_monosyllabic = voiceless_monosyllabic + b_voicingvoiced + `b_voicingvoiced:num_sylmono`,
    delta_voicing_mono = voiceless_monosyllabic - voiced_monosyllabic,
    delta_voicing_di = voiceless_disyllabic - voiced_disyllabic,
    delta_voicing_mono_di = delta_voicing_mono - delta_voicing_di
  )


# define columns to loop through parameters
col_names = c("voiceless_disyllabic", 
              "voiceless_monosyllabic", 
              "voiced_disyllabic",
              "voiced_monosyllabic",
              "delta_voicing_mono",
              "delta_voicing_di",
              "delta_voicing_mono_di"
)

# create empty vectors
name = lci_SC = uci_SC = mean_SC = c()

# SC: extract posterior means and 95% CIs
for (i in 1:length(col_names)) {
  lci_SC <- c(lci_SC, round(coda::HPDinterval(as.mcmc(psamples_SC[[col_names[i]]])), 0)[1])
  uci_SC <- c(uci_SC, round(coda::HPDinterval(as.mcmc(psamples_SC[[col_names[i]]])), 0)[2])
  mean_SC <- c(mean_SC, round(mean(psamples_SC[[col_names[i]]]), 0))
  name <- c(name, col_names[i])
}

# SC: save parameters 
posteriors_SC = data.frame(name, mean_SC, lci_SC, uci_SC)
posteriors_SC$post_SC <- paste0(mean_SC, " [", lci_SC, ",", uci_SC, "]")

name = lci_TR = uci_TR = mean_TR = c()

# TR: extract posterior means and 95% CIs
for (i in 1:length(col_names)) {
  lci_TR <- c(lci_TR, round(coda::HPDinterval(as.mcmc(psamples_TR[[col_names[i]]])), 0)[1])
  uci_TR <- c(uci_TR, round(coda::HPDinterval(as.mcmc(psamples_TR[[col_names[i]]])), 0)[2])
  mean_TR <- c(mean_TR, round(mean(psamples_TR[[col_names[i]]]), 0))
  name <- c(name, col_names[i])
}

# TR: save parameters 
posteriors_TR = data.frame(name, mean_TR, lci_TR, uci_TR)
posteriors_TR$post_TR <- paste0(mean_TR, " [", lci_TR, ",", uci_TR, "]")

name = lci_TR_slopes = uci_TR_slopes = mean_TR_slopes = c()

# TR_slopes: extract posterior means and 95% CIs
for (i in 1:length(col_names)) {
  lci_TR_slopes <- c(lci_TR_slopes, round(coda::HPDinterval(as.mcmc(psamples_TR_slopes[[col_names[i]]])), 0)[1])
  uci_TR_slopes <- c(uci_TR_slopes, round(coda::HPDinterval(as.mcmc(psamples_TR_slopes[[col_names[i]]])), 0)[2])
  mean_TR_slopes <- c(mean_TR_slopes, round(mean(psamples_TR_slopes[[col_names[i]]]), 0))
  name <- c(name, col_names[i])
}

# TR_slopes: save parameters
posteriors_TR_slopes = data.frame(name, mean_TR_slopes, lci_TR_slopes, lci_TR_slopes, uci_TR_slopes)
posteriors_TR_slopes$post_TR_slopes <- paste0(mean_TR_slopes, " [", lci_TR_slopes, ",", uci_TR_slopes, "]")

# merge all of them to compare
post_all <- full_join(posteriors_SC, posteriors_TR) %>% 
  full_join(posteriors_TR_slopes) %>% 
  select(name, post_SC, post_TR, post_TR_slopes)

write.table(post_all, file = "posterior_summary.csv" )
